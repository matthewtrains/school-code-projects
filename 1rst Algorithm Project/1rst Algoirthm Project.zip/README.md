
# Primes Generator

This code generates a bunch of primes, the first algoirthm is the slower one, while the 2nd algoirthm is the faster one.


## Usage

Run the program, it will generate all the primes and then count them. After the 1rst algorithm is finished, the 2nd one will auto start, it will take 30 seconds to start. Once both algorithms are finished running, the counted primes will be shown.



